import { defineModule } from "@rpgjs/common";
import { RpgServer } from "@rpgjs/server";
import { player } from './player'
import { Npc, MeadowCreature, Ranger, Campfire, Trainer } from "./event";
import { MIRA, ROWAN, TRAINER_SPOTS } from './field';

export default defineModule<RpgServer>({
  player,
  maps: [{
    id: 'simplemap',
    events: [
      { id: 'npc', x: MIRA.x, y: MIRA.y, event: Npc() },
      { id: 'rowan', x: ROWAN.x, y: ROWAN.y, event: Ranger() },
      { id: 'meadow-creature', x: 560, y: 256, event: MeadowCreature() },
      // The `campfire` object in simplemap.tmx's Animated layer.
      { id: 'campfire', x: 256, y: 416, event: Campfire() },
      ...Object.entries(TRAINER_SPOTS).map(([id, p]) => ({ id: `trainer-${id}`, x: p.x, y: p.y, event: Trainer(id) })),
    ],
  }],
});
