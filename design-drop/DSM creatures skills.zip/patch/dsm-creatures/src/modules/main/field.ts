import { Move, type RpgPlayer } from '@rpgjs/server';
import { GameError, SPECIES, TRAINERS, displayName, type Command } from '../../domain/game';
import type { ShopItem } from '../../integrations/dsm/terms';
import { session } from './journey';
import { portraitDialogue, talkToRowan, isSpeaking } from './dialogue';
import { onCommitted, openMarket, shop, useCommit, useHudData, useReadState, walked, walletCoins, web2 } from './dsm';
const inside = new WeakSet<RpgPlayer>();
const walking = new WeakSet<RpgPlayer>();
const fighting = new WeakSet<RpgPlayer>();
/** NPC anchors match server.ts event positions and the camp layout in simplemap.tmx (fieldmap-v10). */
export const MIRA = { x: 304, y: 432 }, ROWAN = { x: 304, y: 368 };
/** Trainers: Tess by the meadow's west edge, Kai on the pond's north bank. */
export const TRAINER_SPOTS: Record<string, { x: number; y: number }> = { kade: { x: 400, y: 272 }, nessa: { x: 624, y: 336 } };
/** Bramble's door tile; stepping on it opens the shop board. */
export const SHOP_DOOR = { tx: 18, ty: 4 };
/** Wild meadow bounds (tiles 14..19 × 6..10); the bottom row is plain lawn so the pond is reachable without an encounter. */
export const MEADOW = { x0: 448, x1: 640, y0: 192, y1: 352 };
/** Pond water tiles (tx,ty); casting is allowed from any 4-neighbour of these. */
export const POND = new Set(["17,12","18,12","19,12","20,12","21,12","17,13","18,13","19,13","20,13","21,13","22,13","16,14","17,14","18,14","19,14","20,14","21,14","22,14","16,15","17,15","18,15","19,15","20,15","21,15","22,15","16,16","17,16","18,16","19,16","20,16","21,16","22,16","17,17","18,17","19,17","20,17","21,17","17,18","18,18","19,18","20,18"]);
const T = 32;
export function nearPond(player: RpgPlayer): boolean {
  const tx = Math.floor(player.x() / T), ty = Math.floor(player.y() / T);
  return [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => POND.has(`${tx + dx},${ty + dy}`));
}
function nearNpc(player: RpgPlayer): string | undefined {
  const spots: [string, { x: number; y: number }][] = [['Mira', MIRA], ['Rowan', ROWAN], ...Object.entries(TRAINER_SPOTS).map(([id, p]) => [TRAINERS[id].name, p] as [string, { x: number; y: number }])];
  const near = spots.map(([name, p]) => [name, Math.hypot(player.x() - p.x, player.y() - p.y)] as const).filter(([, d]) => d <= 72).sort((a, b) => a[1] - b[1]);
  return near[0]?.[0];
}
const trainerByName = (name: string | undefined) => Object.keys(TRAINERS).find((id) => TRAINERS[id].name === name);
const atShopDoor = (player: RpgPlayer) => Math.floor(player.x() / T) === SHOP_DOOR.tx && Math.floor(player.y() / T) === SHOP_DOOR.ty;
export function hudData(player: RpgPlayer, extra: Record<string, unknown> = {}) {
  const state = session(player).read();
  const who = nearNpc(player);
  const trainer = trainerByName(who);
  return {
    state, mode: 'field', nearPond: nearPond(player), nearNpc: who, atShop: atShopDoor(player),
    walletCoins: walletCoins(player),
    trainerBeaten: trainer ? state.trainersBeaten.includes(trainer) : false,
    ...extra,
  };
}
/** The one way a command changes the game state: the reducer, then what it means underneath. */
export function commit(player: RpgPlayer, command: Command, revision: number) {
  const local = session(player);
  const before = local.read();
  const next = local.execute(command, revision, `${before.holder}/command/${revision}`);
  player.creatureSave.set(local.snapshot());
  player.getGui('field-hud')?.update(hudData(player));
  onCommitted(player, command, before, next);
  return next;
}
// DSM tasks change the game state through the reducer, as every command does.
useCommit((player, command) => commit(player, command, session(player).read().revision));
useReadState((player) => session(player).read());
useHudData((player) => hudData(player));
export function fieldHud(player: RpgPlayer) {
  const hud = player.gui('field-hud');
  hud.on<{ action: string; direction?: string; creatureId?: string; nick?: string; item?: string }>('field', async ({ action, direction, creatureId, nick, item }) => {
    if (fighting.has(player) || isSpeaking(player)) return;
    if (action === 'walk') {
      const routes = { up: Move.tileUp, down: Move.tileDown, left: Move.tileLeft, right: Move.tileRight };
      if (!direction || !(direction in routes) || walking.has(player)) return;
      walking.add(player);
      try { await player.moveRoutes([routes[direction as keyof typeof routes].call(Move, 2)]); }
      finally { walking.delete(player); hud.update(hudData(player)); }
      return;
    }
    if (action === 'talk') {
      const who = nearNpc(player);
      if (who) web2(player, 'Talking', 'Dialogue runs on the game server: no DSM');
      const trainer = trainerByName(who);
      if (who === 'Rowan') await talkToRowan(player);
      else if (who === 'Mira') await restAtCamp(player);
      else if (trainer) await challengeTrainer(player, trainer);
      else if (nearPond(player)) await startBattle(player, 'cast');
      else hud.update(hudData(player, { notice: 'Walk to Mira at the rest camp to talk.' }));
      return;
    }
    if (action === 'cast') { if (nearPond(player)) await startBattle(player, 'cast'); return; }
    if (action === 'set-lead' && creatureId) { tryCommit(player, { type: 'set-lead', creatureId }); return; }
    if (action === 'rename' && creatureId) { tryCommit(player, { type: 'rename', creatureId, nick: nick ?? '' }); return; }
    if (action === 'shop') { hud.update(hudData(player, { shopOpen: true, shopStatus: '' })); return; }
    if (action === 'buy' && item) { shop(player, item as ShopItem); return; }
    if (action === 'use-item' && item && creatureId) { tryCommit(player, { type: 'use-item', item: item as 'poultice' | 'tonic', creatureId }); return; }
    if (action === 'challenge' && trainerByName(nearNpc(player))) { await challengeTrainer(player, trainerByName(nearNpc(player))!); return; }
    if (action === 'market') { await openMarket(player); fieldHud(player); return; }
  });
  void hud.open(hudData(player));
}
function tryCommit(player: RpgPlayer, command: Command) {
  try { commit(player, command, session(player).read().revision); }
  catch (error) {
    if (!(error instanceof GameError)) throw error;
    player.getGui('field-hud')?.update(hudData(player, { notice: player.t(`game.error.${error.code}`) }));
  }
}
export async function checkEncounter(player: RpgPlayer) {
  // The game starts once the wallet is connected.
  if (!player.creatureSave()) return;
  walked(player);
  const x = player.x(), y = player.y();
  const inWild = x >= MEADOW.x0 && x <= MEADOW.x1 && y >= MEADOW.y0 && y <= MEADOW.y1;
  if (atShopDoor(player)) { player.getGui('field-hud')?.update(hudData(player, { shopOpen: true, shopStatus: '' })); }
  if (!inWild) { inside.delete(player); return; }
  if (inside.has(player) || fighting.has(player)) return;
  inside.add(player);
  await startBattle(player, 'encounter');
}
async function challengeTrainer(player: RpgPlayer, trainer: string) {
  const t = TRAINERS[trainer];
  const portrait = trainer as 'kade' | 'nessa';
  const who = `${t.name} · ${t.title}`;
  const state = session(player).read();
  if (state.trainersBeaten.includes(trainer)) { await portraitDialogue(player, [{ speaker: who, portrait, message: t.beaten }]); return; }
  if (state.creatures[state.lead].hp === 0) { await portraitDialogue(player, [{ speaker: who, portrait, message: 'Your lead can barely stand. See Mira first, then we’ll talk.' }]); return; }
  web2(player, 'Trainer', `${t.name} challenges you: the battle runs on the game server`);
  await portraitDialogue(player, t.greeting.map((message) => ({ speaker: who, portrait, message })));
  await startBattle(player, 'challenge', trainer);
  const outcome = session(player).read().battle?.outcome;
  if (outcome === 'victory') await portraitDialogue(player, [{ speaker: who, portrait, message: t.win }]);
  else if (outcome === 'defeat') await portraitDialogue(player, [{ speaker: who, portrait, message: t.lose }]);
}
async function startBattle(player: RpgPlayer, kind: 'encounter' | 'cast' | 'challenge', trainer?: string) {
  if (fighting.has(player)) return;
  const state = session(player).read();
  const lead = state.creatures[state.lead];
  if (!lead.hp) {
    player.getGui('field-hud')?.update(hudData(player, { notice: `${displayName(lead)} needs rest. Swap leads in the BAG or talk to Mira.` }));
    return;
  }
  fighting.add(player);
  player.breakRoutes(true);
  try {
    if (kind === 'cast') { player.getGui('field-hud')?.update(hudData(player, { notice: 'Cast… waiting for a bite.' })); await new Promise(r => setTimeout(r, 1600)); }
    const command: Command = kind === 'challenge' ? { type: 'challenge', trainer: trainer! } : { type: kind };
    let next;
    try { next = state.battle?.outcome === 'active' ? state : commit(player, command, state.revision); }
    catch (error) {
      if (!(error instanceof GameError)) throw error;
      player.getGui('field-hud')?.update(hudData(player, { notice: player.t(`game.error.${error.code}`) }));
      return;
    }
    const gui = player.gui('creature-battle');
    gui.on<{ action: string; revision: number; nick?: string }>('battle', ({ action, revision, nick }) => {
      if (action === 'continue') {
        if (session(player).read().battle?.outcome !== 'active') gui.close();
        return;
      }
      const current = session(player).read();
      const combatant = current.creatures.find(c => c.id === current.battle?.creatureId) ?? current.creatures[current.lead];
      const isMove = SPECIES[combatant.species].moves.some(m => m.id === action);
      const command: Command | undefined = isMove ? { type: 'move', move: action }
        : action === 'capture' ? { type: 'capture', nick } : action === 'escape' ? { type: 'escape' } : undefined;
      if (!command) return;
      try { gui.update({ state: commit(player, command, revision), mode: 'battle', lastAction: action, error: '' }); }
      catch (error) {
        if (!(error instanceof GameError)) throw error;
        gui.update({ state: session(player).read(), mode: 'battle', error: player.t(`game.error.${error.code}`) });
      }
    });
    await gui.open({ state: next, mode: 'battle', lastAction: '', error: '' }, { waitingAction: true, blockPlayerInput: true });
  } finally { fighting.delete(player); player.getGui('field-hud')?.update(hudData(player)); }
}
export async function restAtCamp(player: RpgPlayer) {
  if (fighting.has(player) || isSpeaking(player)) return;
  commit(player, { type: 'heal' }, session(player).read().revision);
  await portraitDialogue(player, [
    { speaker: 'Mira · Camp Healer', portrait: 'mira', message: 'There you are! Your creatures have rested by the campfire. Their HP and special moves are full again.' },
    { speaker: 'You', portrait: 'player', message: 'Thanks, Mira. We’re ready to explore the meadow again.' },
    { speaker: 'Mira · Camp Healer', portrait: 'mira', message: 'Take care out there. A new companion keeps the HP it had when you caught it, so bring it to me for a rest too.' },
  ]);
}
