import { type EventDefinition } from '@rpgjs/server';
import { restAtCamp } from './field';
export function Npc(): EventDefinition {
  return {
    onInit() { this.setGraphic('female'); },
    async onAction(player) { await restAtCamp(player); },
  };
}

/** The camp's fire: the logs and stones are in the map image; the flames are this sprite. */
export function Campfire(): EventDefinition {
  return { onInit() { this.setGraphic('campfire'); } };
}

export function MeadowCreature(): EventDefinition {
  return { onInit() { this.setGraphic('mossling'); } };
}

import { talkToRowan } from './dialogue';
/** A trainer standing on the map; TALK beside them starts the challenge (field.ts). */
export function Trainer(graphic: string): EventDefinition {
  return { onInit() { this.setGraphic(graphic); } };
}
export function Ranger(): EventDefinition {
  return { onInit() { this.setGraphic('ranger'); }, async onAction(player) { await talkToRowan(player); } };
}
