import { provideI18n, provideClientGlobalConfig, provideClientModules, Presets } from "@rpgjs/client";
import { Animation } from "@rpgjs/common";
import i18n from "../i18n";
import { provideTiledMap } from "@rpgjs/tiledmap/client";

import { provideVueGui, vueGui } from '@rpgjs/vue';
import Dialogue from '../gui/Dialogue.vue';
import Play from '../gui/Play.vue';
import DsmPanel from '../gui/DsmPanel.vue';
import DsmConnect from '../gui/DsmConnect.vue';
import Market from '../gui/Market.vue';

export default {
  providers: [
    provideVueGui({ createIfNotFound: true }),
    provideTiledMap({
      basePath: "map",
    }),
    provideClientGlobalConfig(),
    provideI18n(i18n),
    provideClientModules([
      {
        gui: [
          vueGui({id: 'portrait-dialogue', component: Dialogue}), vueGui({id: 'field-hud', component: Play}), vueGui({id: 'creature-battle', component: Play}),
          // DSM mode: the wallet connect code, the market, and the overlay of what runs underneath.
          vueGui({id: 'dsm-connect', component: DsmConnect}), vueGui({id: 'dsm-market', component: Market}), vueGui({id: 'dsm-panel', component: DsmPanel}),
        ],
        spritesheets: [
          { id: 'ranger', image: 'spritesheets/ranger.png', displayScale: 0.030927835051546393, ...Presets.RMSpritesheet(1, 1) },
          // Trainers: single 32x40 frames on the hero's pixel grid (no scaling).
          { id: 'kade', image: 'spritesheets/kade.png', width: 32, height: 40, framesWidth: 1, framesHeight: 1 },
          { id: 'nessa', image: 'spritesheets/nessa.png', width: 32, height: 40, framesWidth: 1, framesHeight: 1 },
          { id: 'mossling', image: 'creatures/mossling.png', displayScale: 0.03609022556390978, ...Presets.RMSpritesheet(1, 1) },
          // Three 32px frames at 8 fps, looping while the fire stands.
          {
            id: 'campfire', image: 'fx/campfire.png', framesWidth: 3, framesHeight: 1,
            textures: { [Animation.Stand]: { animations: () => [[
              { time: 0, frameX: 0, frameY: 0 }, { time: 8, frameX: 1, frameY: 0 }, { time: 16, frameX: 2, frameY: 0 }, { time: 24 },
            ]] } },
          },
          {
            id: 'hero',
            image: 'spritesheets/hero.png',
            ...Presets.RMSpritesheet(3, 4)
          },
          {
            id: 'female',
            image: 'spritesheets/female.png',
             ...Presets.RMSpritesheet(3, 4)
          }
        ]
      }
    ])
  ],
};
