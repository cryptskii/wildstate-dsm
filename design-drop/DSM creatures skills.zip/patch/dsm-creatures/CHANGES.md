# Shop, items, trainer battles

Copy every file in this folder over the matching path in `dsm-creatures/`, then `npm test && npm run typecheck && npm run build`.

## Why the shop looked dead
WILD never lives in the game state: `state.coins` is the last holdings proof from the wallet, and the old SHOP button fired one capsule purchase through the wallet with no screen and no feedback until the next proof landed. There was also no item other than the capsule, and the only income was the 5 WILD wild-battle reward.

## What changed
- **terms.ts**: `ITEM_PRICES` (capsule 3, poultice 4, tonic 6 WILD), `TRAINER_REWARD` 12 WILD.
- **game.ts**: `grant-item` (one grant per accepted payment fact), `use-item` (poultice +15 HP, tonic restores charges; outside battle), `challenge` (trainer battle: full-strength foe, alternates signature/status moves, no capture, +15 XP), `trainersBeaten` cleared by `heal` so trainers can be re-fought after a rest. `TRAINERS`: Kade, Meadow Drifter (Mossling "Burr") and Nessa, Pond Keeper (Tidefin "Ripple").
- **dsm.ts**: `buyItem` replaces `buyCapsule`; the wallet pays, the game account confirms, the reducer grants the item. The seat's known balance is debited immediately so the HUD does not lag until the next proof. Trainer victory enqueues a `TRAINER_REWARD` transfer from the game account.
- **field.ts**: HUD actions `buy`, `use-item`, `challenge`; shop board opens from the SHOP button or by stepping on Bramble's door; trainers are TALK/FIGHT targets at `TRAINER_SPOTS`.
- **event.ts / server.ts / config.client.ts**: `Trainer(graphic)` events at the trainer spots with their own sheets (`public/spritesheets/kade.png`, `nessa.png`).
- **dialogue.ts / portraits**: Kade and Nessa talk before the fight and after it (win, loss, already beaten) with `public/portraits/kade.png`, `nessa.png`.
- **Play.vue**: Bramble's board (prices, your wallet balance, BUY, status line), USE buttons in the Bag, FIGHT button and bounty hint near a trainer, trainer battle header/names/messages, Forfeit instead of Run.
- **i18n.ts**: new error strings.
- **test/game.test.ts**: 3 new tests.

## Reading the balance
Spending shows at once (seat debit); earning shows when the holdings proof after the transfer lands (a few seconds, visible in the DSM panel). Without `DSM_APP_HOST` the game does not start, as before.

## Prototype parity
The HTML prototype (`Field mobile` / `Battle mobile`) mirrors the trainer flow: Kade at the meadow edge, Nessa on the pond bank, portrait dialogue before the fight, TRAINER BATTLE mode (no capture, Forfeit, 12 WILD bounty), rematch after resting with Mira.

## Growth (leveling)
- **game.ts**: `level`, `maxHp`, `damageBonus`, `maxCharges`, `xpGain`, `wildLevel`, `grantXp`; wild creatures spawn at `wildLevel(n)` with 70% HP, trainers at `TRAINER_LEVEL`; battle gains `growth`. Schema: HP ceiling 76, charges ≤ 7. State rules id unchanged (`creatures-v4`); existing saves are forward-compatible (xp already stored).
- **Play.vue**: level-up card after a fight (tap to dismiss), LV/XP bar + DMG bonus in the Bag, HP shown against the creature's own max.
- **test/game.test.ts**: 4 growth tests.
